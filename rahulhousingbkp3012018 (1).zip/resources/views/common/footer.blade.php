        <script type="text/javascript" src="{{ URL::asset('public/js/bootstrap.js') }}"></script>        
        <script type="text/javascript" src="{{ URL::asset('public/js/bootstrap-datepicker.js') }}"></script>
    </body>
</html>