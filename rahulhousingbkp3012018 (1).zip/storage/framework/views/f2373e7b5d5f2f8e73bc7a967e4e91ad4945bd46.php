<?php echo $__env->make('common.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class='container'>
    <div class='row'>
        <div class="col-md-8">
        <?php echo Form::open(['route'=>'review.store']); ?>

        <div class="col-md-12">
            <h1>Add QC Review</h1>
        </div>
        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('date','File Review Date',['class'=>'col-sm-6 control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::text('reviewdate',null,['placeholder'=>'Review Date', 'class'=>'form-control input-append date', 'id'=>'datepicker3']); ?>

        </div>

        
        <div class='col-md-6  form-group'>
            <?php echo Form::label('review','Review By',['class'=>'col-sm-6 control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::select('reviewbyid',$data,null,['placeholder'=>'Select Review By','class'=>'form-control col-sm-6']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('type','Review Type',['class'=>'col-sm-6 control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::select('reviewtypeid',$reviewType,null,['placeholder'=>'Select Review type', 'class'=>'form-control col-sm-6']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('program','Program  Type',['class'=>'col-sm-6 control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::select('programtypeid',$programType,null,['placeholder'=>'Select Program Type', 'class'=>'form-control col-sm-6']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('action','Action Type',['class'=>'col-sm-6 control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::select('actiontypeid',$actionType,null,['placeholder'=>'Select Action Type', 'class'=>'form-control col-sm-6']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('effecetive','Effective Action Date ',['class'=>'control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::text('efectiveactiondate',null,['placeholder'=>'Enter Effective Action Date', 'class'=>'form-control input-append date', 'id'=>'datepicker']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('annual','Annual Inception Date',['class'=>'control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::text('annualinceptiondate',null,['placeholder'=>'Enter Annual Inception Date', 'class'=>'form-control input-append date', 'id'=>'datepicker1']); ?>

        </div>

        
        <div class='col-md-6 form-group'>
            <?php echo Form::label('failed','Failed Inception Date',['class'=>'control-label']); ?>

        </div>
        <div class='col-md-6 form-group'>
            <?php echo Form::text('failedinceptiondate',null,['placeholder'=>'Enter Failed Inception Date', 'class'=>'form-control input-append date', 'id'=>'datepicker2']); ?>

        </div>
        
        
        <div class='col-md-6 form-group'>
            <?php echo Form::submit('Create Review',['class'=>'btn btn-primary']); ?>

        </div>


        <?php echo Form::close(); ?>

         </div>
    </div>
</div>

<script>
    $(document).ready(function(){
        $('#datepicker,#datepicker1,#datepicker2').datepicker({
            autoclose: true
        });
        $('#datepicker3').datepicker().datepicker("setDate", new Date());
    });
</script>
<?php echo $__env->make('common.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>