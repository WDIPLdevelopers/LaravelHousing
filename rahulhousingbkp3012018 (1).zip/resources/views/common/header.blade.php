<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Housing</title>
        
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('public/css/bootstrap.min.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ URL::asset('public/css/bootstrap-datepicker.css') }}">
        <script type="text/javascript" src="{{ URL::asset('public/js/jquery.min.js') }}"></script>      
        
    </head>
    <body>
       
    
