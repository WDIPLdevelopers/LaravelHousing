<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Programtype extends Model
{
    //
}
